# SSHPLUS

apt update -y && apt upgrade -y && wget https://raw.githubusercontent.com/kiritosshxd/SSHPLUS/master/Plus && chmod 777 Plus && ./Plus


#Acessa Root

wget https://raw.githubusercontent.com/proxynerd/SSHPLUS/git/senharoot.sh && chmod 777 senharoot.sh && ./senharoot.sh
